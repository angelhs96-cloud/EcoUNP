/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RecycledAction } from '../types';
import { Award, CheckCircle, Lock, Calendar, ClipboardList, Info, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HistoryScreenProps {
  actions: RecycledAction[];
}

export default function HistoryScreen({ actions }: HistoryScreenProps) {
  const [selectedSem, setSelectedSem] = useState<number>(3); // Default highlighted week is SEM 3 (8.5 Kg)
  const [activeBadge, setActiveBadge] = useState<string | null>(null);

  // Kg savings detailed stats per week
  const weekData = [
    { sem: 1, kg: 3.2, title: "Semana 1: Arranque Verde", date: "01 Oct - 07 Oct" },
    { sem: 2, kg: 4.8, title: "Semana 2: Impulso Sostenible", date: "08 Oct - 14 Oct" },
    { sem: 3, kg: 8.5, title: "Semana 3: Consolidación Sólida", date: "15 Oct - 21 Oct", active: true },
    { sem: 4, kg: 6.0, title: "Semana 4: Cierre Eco-Responsable", date: "22 Oct - 28 Oct" }
  ];

  const totalKg = weekData.reduce((acc, curr) => acc + curr.kg, 0).toFixed(1);

  // Student Badges
  const badgesList = [
    { id: '1', name: "Pionero Verde", icon: "🌱", desc: "Haber registrado tu primera acción rápida de reciclaje", unlocked: true },
    { id: '2', name: "Cero Plástico", icon: "🥤", desc: "Registrar 5 días seguidos con uso de tomatodo personal", unlocked: true },
    { id: '3', name: "Ciclista Urbano", icon: "🚲", desc: "Acumular 50 km recorridos en transporte sustentable", unlocked: false },
    { id: '4', name: "Guardián Bosque", icon: "🌲", desc: "Haber participado en 3 eventos de reforestación", unlocked: false },
    { id: '5', name: "Maestro Compost", icon: "🍂", desc: "Llevar residuos orgánicos al tacho de compost por 10 días", unlocked: false },
    { id: '6', name: "Energía Pura", icon: "⚡", desc: "Lograr apagar todos los equipos del laboratorio 5 veces", unlocked: false },
  ];

  return (
    <div className="flex flex-col gap-6">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-ink">Historial de Sostenibilidad</h2>
        <p className="text-xs text-ink-muted/60">Monitorea tus estadísticas y logros en tiempo real</p>
      </div>

      {/* Statistics Chart Module */}
      <div className="bg-surface/90 rounded-2xl p-5 border border-line/50 shadow-xl shadow-black/40">
        <div className="flex justify-between items-center mb-1">
          <h3 className="text-xs uppercase tracking-widest text-ink-muted/60 font-bold">
            Impacto Ambiental
          </h3>
          <span className="text-lg font-extrabold text-[#00E676] font-mono tracking-tight drop-shadow-[0_0_8px_rgba(0,230,118,0.3)]">
            {totalKg} Kg
          </span>
        </div>
        <p className="text-xs text-ink-muted/50 mb-4">Plástico ahorrado este mes • campus central</p>

        {/* Sleek Bar Chart */}
        <div className="h-40 relative flex items-end justify-between border-b border-ink/10 pb-1 pt-2">
          {/* Horizontal Grid lines */}
          <div className="absolute inset-x-0 top-0 bottom-0 flex flex-col justify-between pointer-events-none opacity-10">
            <div className="w-full h-[1.5px] bg-ink-muted" />
            <div className="w-full h-[1.5px] bg-ink-muted" />
            <div className="w-full h-[1.5px] bg-ink-muted" />
            <div className="w-full h-[1.5px] bg-ink-muted" />
          </div>

          {/* Render bars */}
          <div className="w-full flex justify-between items-end h-full px-2 z-10">
            {weekData.map((w) => {
              const heightPercent = `${Math.min(95, (w.kg / 10) * 100)}%`;
              const isSelected = selectedSem === w.sem;
              
              return (
                <div 
                  key={w.sem} 
                  onClick={() => setSelectedSem(w.sem)}
                  className="flex flex-col items-center gap-2 cursor-pointer group flex-1"
                >
                  <div className="w-full max-w-[48px] h-32 flex items-end relative">
                    {/* Pulsing bar */}
                    <div 
                      style={{ height: heightPercent }}
                      className={`w-full rounded-t-lg transition-all duration-500 ease-out relative ${
                        isSelected 
                          ? 'bg-[#00E676] shadow-[0_0_20px_rgba(0,230,118,0.55)] border-t border-ink/30' 
                          : 'bg-surface2 hover:bg-line border-t border-ink/5'
                      }`}
                    >
                      {/* Interactive weight label on hover or click */}
                      <span className={`absolute -top-7 left-1/2 -translate-x-1/2 text-[10px] font-mono px-1.5 py-0.5 rounded-md border font-bold transition-all ${
                        isSelected 
                          ? 'bg-surface2 border-[#00E676]/30 text-[#00E676] scale-110 opacity-100' 
                          : 'bg-surface2 border-ink/5 text-ink/40 opacity-0 group-hover:opacity-100'
                      }`}>
                        {w.kg}k
                      </span>
                    </div>
                  </div>
                  <span className={`text-[9px] font-bold uppercase tracking-wide tracking-tighter ${
                    isSelected ? 'text-[#00E676]' : 'text-ink-muted/40'
                  }`}>
                    SEM {w.sem}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Dynamic Detail of Selected Week */}
        {selectedSem && (
          <div className="mt-4 p-3 bg-surface2/80 border border-ink/5 rounded-xl flex items-center justify-between text-xs transition-all">
            <div>
              <p className="text-ink font-semibold">{weekData[selectedSem - 1].title}</p>
              <p className="text-ink-muted/50 text-[10px]">{weekData[selectedSem - 1].date}</p>
            </div>
            <span className="font-mono text-xs font-extrabold text-[#00E676] bg-[#00E676]/10 px-2 py-1 rounded-md border border-[#00E676]/10 shrink-0">
              {weekData[selectedSem - 1].kg} Kg Evitados
            </span>
          </div>
        )}
      </div>

      {/* Timeline Section */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-bold text-ink flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-[#00E676]" />
          Actividad Reciente
        </h3>
        
        <div className="bg-surface/90 rounded-2xl p-5 border border-line/50 max-h-[290px] overflow-y-auto shadow-xl shadow-black/40 pr-3">
          <div className="flex flex-col gap-5">
            {actions.map((act, idx) => (
              <div key={act.id} className="flex gap-3 relative group">
                {/* Visual timeline connector line */}
                {idx < actions.length - 1 && (
                  <div className="absolute left-[13px] top-7 bottom-[-24px] w-[2px] bg-ink/10 group-hover:bg-[#00E676]/30 transition-colors" />
                )}

                <div className="w-7 h-7 rounded-full bg-surface2 border border-ink/10 flex items-center justify-center shrink-0 z-10 mt-0.5 text-xs">
                  {act.icon === "recycling" ? "♻️" : act.icon === "water" ? "🥤" : act.icon === "bike" ? "🚲" : "⚡"}
                </div>

                <div className="flex-1 flex justify-between items-start">
                  <div>
                    <h4 className="text-ink text-xs font-semibold">{act.title}</h4>
                    <p className="text-[10px] text-ink-muted/50 mt-0.5 flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-[#00E676]" />
                      {act.date}
                    </p>
                  </div>
                  <span className="text-xs font-extrabold text-[#00E676] bg-[#00E676]/10 px-2 py-0.5 rounded border border-[#00E676]/10 font-mono shrink-0">
                    +{act.points} pts
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Achievements Badge Grid */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-bold text-ink flex items-center gap-2">
          <Award className="w-4 h-4 text-[#00E676]" />
          Insignias y Logros
        </h3>

        <div className="grid grid-cols-2 gap-3">
          {badgesList.map((badge) => (
            <div
              key={badge.id}
              onClick={() => setActiveBadge(activeBadge === badge.id ? null : badge.id)}
              className={`p-4 rounded-xl flex flex-col items-center justify-center text-center relative overflow-hidden transition-all duration-300 border cursor-pointer select-none ${
                badge.unlocked 
                  ? 'bg-gradient-to-b from-surface to-surface2 border-[#00E676]/30 shadow-[0_0_15px_rgba(0,230,118,0.06)]' 
                  : 'bg-surface2/80 opacity-60 border-ink/5 grayscale'
              }`}
            >
              {/* Lock overlay icon */}
              {!badge.unlocked && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-black/40 flex items-center justify-center">
                  <Lock className="w-2.5 h-2.5 text-ink-muted/40" />
                </div>
              )}

              {badge.unlocked && (
                <div className="absolute top-2 right-2 flex items-center justify-center text-[10px] text-[#00E676] bg-[#00E676]/10 border border-[#00E676]/20 px-1 rounded font-bold animate-pulse">
                  OK
                </div>
              )}

              <span className={`text-3xl mb-2 filter drop-shadow-[0_0_8px_rgba(0,230,118,0.2)] ${
                badge.unlocked ? 'animate-bounce-slow' : ''
              }`}>
                {badge.icon}
              </span>
              
              <h4 className={`text-xs font-bold leading-tight ${
                badge.unlocked ? 'text-[#00E676]' : 'text-ink/60'
              }`}>
                {badge.name}
              </h4>

              {/* Collapsible Info Drawer on Card click */}
              <AnimatePresence>
                {activeBadge === badge.id && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden mt-2 pt-2 border-t border-ink/5 w-full text-[10px] text-ink-muted text-left leading-relaxed font-medium"
                  >
                    {badge.desc}
                    <div className="mt-1 font-bold italic text-[#00E676]">
                      {badge.unlocked ? "¡Insignia obtenida!" : "🔒 Bloqueado"}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
