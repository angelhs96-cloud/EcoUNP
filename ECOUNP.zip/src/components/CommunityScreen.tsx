/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { VolunteerEvent, StudentInfo, RecycledAction } from '../types';
import { Calendar, Clock, Sparkles, Trophy, Users, CheckCircle, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CommunityScreenProps {
  events: VolunteerEvent[];
  student: StudentInfo;
  onRegisterEvent: (eventId: string, cost: number) => void;
}

export default function CommunityScreen({
  events,
  student,
  onRegisterEvent,
}: CommunityScreenProps) {
  const [insufficientPointsError, setInsufficientPointsError] = useState<string | null>(null);

  const handleRegisterClick = (evt: VolunteerEvent) => {
    if (student.points < evt.pointsCost) {
      setInsufficientPointsError(
        `Necesitas ${evt.pointsCost} pts para inscribirte en "${evt.title}". Tu saldo actual es de ${student.points} pts.`
      );
      // Suppress alert automatically after 3 seconds
      setTimeout(() => {
        setInsufficientPointsError(null);
      }, 3500);
      return;
    }
    
    // Deduct and change state of event in the main app
    onRegisterEvent(evt.id, evt.pointsCost);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Title */}
      <div>
        <h2 className="text-xl font-bold tracking-tight text-ink">Comunidad UNP Sostenible</h2>
        <p className="text-xs text-ink-muted/60">Monitorea el ranking estudiantil y asiste a voluntariados</p>
      </div>

      {/* Insufficient points alert banner */}
      <AnimatePresence>
        {insufficientPointsError && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="p-3.5 bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-xs flex gap-2 items-start shadow-lg"
          >
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Saldo Insuficiente en Billetera</p>
              <p className="mt-0.5 opacity-90">{insufficientPointsError}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Leadership Rank Podium */}
      <div className="bg-surface/90 rounded-2xl p-5 border border-line/50 shadow-xl shadow-black/40">
        <div className="flex justify-between items-end mb-4">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-ink-muted/60 font-bold">Rendimiento Facultad</h3>
            <p className="text-xs text-ink font-semibold">Computer Engineering Leaderboard</p>
          </div>
          <span className="text-[10px] text-[#00E676] bg-[#00E676]/10 px-2 py-0.5 rounded font-bold uppercase tracking-wide">
            Sarah K. Lidera 🏆
          </span>
        </div>

        {/* Dynamic Podium display matching mockup visuals */}
        <div className="flex items-end justify-center gap-3 h-[210px] pt-4 border-b border-line/30 pb-1 relative">
          {/* Rank 2 Podium */}
          <div className="flex flex-col items-center w-24 relative z-10 transition-transform hover:scale-105 duration-300">
            <div className="relative w-12 h-12 rounded-full border-2 border-secondary mb-2 overflow-hidden bg-surface2 shadow-md shadow-black/50">
              <img 
                className="w-full h-full object-cover" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBmN9QAYbSogAJZyjin0zyjZeRU1BsOz3CkMvtu5C30o3dNqFs_2ony22tuhRDLikr02FblH_r2qv7nXp2WZu019mPHOKZ9ZylMBLlkXweRYnS80Kho5yhzJUjI0D3n45KzLjKB4k-IPyKt6atiGY_Z5nOhu3joDBndU1AhweSyMbcX35dXA627S9wtEoxSCyRyIxrdKvqL500ZXPkEtURYwBJ-cv6b-xa57DMbj1KPRKzJJACiySuEJWuhJQ67Fyr_o4veIKgs-w" 
                alt="Alex M." 
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-stone-750 rounded-full border border-ink/20 flex items-center justify-center text-[10px] font-extrabold text-stone-200">
                2
              </div>
            </div>
            <span className="text-[10px] text-ink font-bold truncate w-full text-center">Alex M.</span>
            <span className="text-[10px] font-mono text-ink-muted/60 font-medium">3,450 pts</span>
            <div className="w-full h-12 bg-gradient-to-t from-white/10 to-transparent rounded-t-lg border-t border-ink/5 mt-2" />
          </div>

          {/* Rank 1 Podium with special crown and glow! */}
          <div className="flex flex-col items-center w-28 -translate-y-4 relative z-20 transition-transform hover:scale-105 duration-300">
            <div className="absolute -top-5 text-[#00E676] animate-pulse">
              <Trophy className="w-4 h-4 fill-[#00E676]" />
            </div>
            <div className="relative w-16 h-16 rounded-full border-2 border-[#00E676] mb-2 overflow-hidden bg-surface2 shadow-[0_0_20px_rgba(0,230,118,0.3)]">
              <img 
                className="w-full h-full object-cover" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuArdAHujf5CSEyXcihjtixm2Aa0zaMvIRw72xD58qhZTbHQMUvw8wZBj88lw0ODvsBfst-V0lNaaXmlNevvUlcxuDu3fkT1ISkZfU-gFvpv8JI53GL6XRI7oG5o7S-wfrjDPNNSaNlrXsC7qIgDhsuTdEzo_y9M6GGUJEnzmkCsMrTQoHZh-2AGjKiimWbW9OdUh79bs7mo8-k0JjPfAJ1wA88I-eO09bRHUv5fwXV3lmoUKzdUe99D3t5b2Wc2RkSJT7GyfDeEJQ" 
                alt="Sarah K." 
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-[#00E676] rounded-full border-2 border-surface2 flex items-center justify-center text-xs font-extrabold text-surface2">
                1
              </div>
            </div>
            <span className="text-xs text-[#00E676] font-bold truncate w-full text-center leading-none">Sarah K.</span>
            <span className="text-[10px] font-mono text-[#00E676] font-extrabold mt-1">4,120 pts</span>
            <div className="w-full h-[68px] bg-gradient-to-t from-[#00E676]/20 to-[#00E676]/5 rounded-t-lg border-t border-[#00E676]/30 mt-2 relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#00E676]/10 to-transparent" />
            </div>
          </div>

          {/* Rank 3 Podium */}
          <div className="flex flex-col items-center w-24 relative z-10 transition-transform hover:scale-105 duration-300">
            <div className="relative w-12 h-12 rounded-full border-2 border-[#ff9587]/40 mb-2 overflow-hidden bg-surface2 shadow-md shadow-black/50">
              <img 
                className="w-full h-full object-cover" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCN4SgV4b-5k6rtCyMSVPtrHO4fxkRN87Wp9pa7wdj47aNmyw3GquVCa7Op75SM93u861PUWpKkrIwZWFwQqocw7R5wvaRpS4MVIxweyI2u_x_DjNFBkzrtzLc1RZ0nNsZbc5RlfLqiQn8GS2slXlvrUHbKD_2Q-h1tViGVahjMw4r94UslXWcVqnTlev0lKHXw7B8NCmaj2-a6zPSM_L-xKZQJmqWouaF8B_Xyr8Kj_5ZSkmsAEVs1fq97dmVg65VB5jSKruVZTw" 
                alt="David R." 
              />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#ff9587]/15 rounded-full border border-[#ff9587]/30 flex items-center justify-center text-[10px] font-extrabold text-[#ff9587]">
                3
              </div>
            </div>
            <span className="text-[10px] text-ink font-bold truncate w-full text-center">David R.</span>
            <span className="text-[10px] font-mono text-ink-muted/60 font-medium">3,100 pts</span>
            <div className="w-full h-8 bg-gradient-to-t from-white/10 to-transparent rounded-t-lg border-t border-ink/5 mt-2" />
          </div>
        </div>

        {/* Global info readout */}
        <div className="mt-4 text-center">
          <p className="text-[10px] text-ink-muted/50 uppercase tracking-widest font-semibold flex items-center justify-center gap-1">
            <Users className="w-3" />
            Estudiantes compitiendo este ciclo: 124
          </p>
        </div>
      </div>

      {/* Volunteer Events Module */}
      <div className="flex flex-col gap-3">
        <h3 className="text-sm font-bold text-ink uppercase tracking-wider">Proyectos de Voluntariado</h3>

        <div className="flex flex-col gap-4">
          {events.map((evt) => {
            const hasJoined = evt.state === 'Inscrito';
            const slotsLeft = evt.slotsMax - evt.slotsCurrent;
            const meetsLimit = slotsLeft <= 0;
            
            return (
              <div
                key={evt.id}
                className="bg-surface border border-ink/5 rounded-2xl p-5 relative overflow-hidden group shadow-xl shadow-black/20"
              >
                {/* Visual side marker card decorator */}
                <div className={`absolute top-0 bottom-0 left-0 w-1 ${hasJoined ? 'bg-[#00E676]' : 'bg-[#00E676]/20'}`} />

                <div className="flex justify-between items-start mb-2.5 pl-1.5">
                  <div className="pr-2">
                    <h4 className="text-ink font-bold text-sm tracking-tight">{evt.title}</h4>
                    <div className="flex items-center gap-3 text-[10px] text-ink-muted/50 font-bold mt-1">
                      <p className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-[#00E676]" />
                        {evt.date}
                      </p>
                      <p className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-[#00E676]" />
                        {evt.time}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end shrink-0">
                    <span className="text-[9px] uppercase font-bold text-ink/40 tracking-wider">Cupos</span>
                    <div className="text-xs font-mono font-bold text-ink bg-surface2 px-2 py-1 rounded border border-ink/5">
                      <span className="text-[#00E676]">{evt.slotsCurrent}</span>
                      <span className="opacity-30">/{evt.slotsMax}</span>
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-ink-muted/70 leading-relaxed mb-4 pl-1.5">
                  {evt.description}
                </p>

                {/* Confirm Enrollment button */}
                <div className="pl-1.5">
                  {hasJoined ? (
                    <div className="bg-[#00E676]/10 text-[#00E676] border border-[#00E676]/30 text-xs font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,230,118,0.06)] animate-pulse">
                      <CheckCircle className="w-4 h-4 fill-[#00E676] text-black" />
                      <span>¡ESTÁS INSCRITO EN ESTE EVENTO! 🎉</span>
                    </div>
                  ) : meetsLimit ? (
                    <button
                      disabled
                      className="w-full bg-surface2 text-ink/30 text-xs font-bold py-3 rounded-xl border border-ink/5 cursor-not-allowed text-center"
                    >
                      VACANTES AGOTADAS 🔒
                    </button>
                  ) : (
                    <button
                      onClick={() => handleRegisterClick(evt)}
                      className="w-full bg-[#00E676] hover:bg-[#1dec85] text-black text-xs font-extrabold py-3 rounded-xl transition-all duration-300 flex items-center justify-center gap-1.5 shadow-lg shadow-[#00E676]/25"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Inscribirme (Consume {evt.pointsCost} puntos)</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
